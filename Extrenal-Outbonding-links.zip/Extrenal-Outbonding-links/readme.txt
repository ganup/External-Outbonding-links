=== External  outbonding links ===
Contributors: Ganesh Paygude
Tags: Page,post,content
Requires at least: 3.2
Tested up to: 4.4.1
Stable tag: 1.0
License: GPLv2
Author: Ganesh Paygude

Its add the rel="external" target="_blank" for external links.

== Description ==

External  outbonding links to add rel="external" target="_blank" attributes to links in page and post content.

Major features in Woo-Tabs include:

* Setting option checkbox allow to apply the attributes to link.
* External links opens in new tab. 

== Installation ==

Upload the External  outbonding links plugin to your website, Activate it,click on checkbox in setting option for allowing to
add attributes for external links.
