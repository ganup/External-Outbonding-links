jQuery(document).ready(function($){
	
    jQuery('.wp-color-picker-field').wpColorPicker();
});