<?php
/*
Plugin Name: External  outbonding links
Plugin URI: 
Version: 1.0
Author: Ganesh Paygude
Description: Add attribute for external links
*/

/* Setup the plugin. */
add_action( 'plugins_loaded', 'my_external_plugin_setup' );

/* Register plugin activation hook. */
register_activation_hook( __FILE__, 'my_external_plugin_activation' );

/* Register plugin activation hook. */
register_deactivation_hook( __FILE__, 'my_external_plugin_deactivation' );
/**
 * Do things on plugin activation.
 *
 */
function my_external_plugin_activation() {
	/* Flush permalinks. */
    flush_rewrite_rules();
}
/**
 * Flush permalinks on plugin deactivation.
 */
function my_external_plugin_deactivation() {
    flush_rewrite_rules();
}
function my_external_plugin_setup() {
// create custom plugin settings menu
/* Get the plugin directory URI. */
define( 'EXTERNAL_LINK_URI', trailingslashit( plugin_dir_url( __FILE__ ) ) );
add_action('admin_menu', 'my_external_plugin_create_menu');

}

function my_external_plugin_create_menu() {

	//create new top-level menu
	add_menu_page('My External link Plugin Settings', 'External link Settings', 'administrator', __FILE__, 'my_external_plugin_settings_page' , plugins_url('/images/link.png', __FILE__) );

	//call register settings function
	add_action( 'admin_init', 'register_my_external_plugin_settings' );
}
function wp_enqueue_color_picker() {    
	
	wp_enqueue_script( 'my-script-handle', EXTERNAL_LINK_URI . '/js/my-script.js', array( 'jquery' ), 0.1, true );
	
}
add_action( 'admin_enqueue_scripts', 'wp_enqueue_color_picker' );

function register_my_external_plugin_settings() {
	//register our settings
	register_setting( 'my-external-plugin-settings-group', 'new_tab' );
	register_setting( 'my-external-plugin-settings-group', 'external_add' );

}

function my_external_plugin_settings_page() {
?>
<div class="wrap">
<h2>External links</h2>

<form method="post" action="options.php">
    <?php settings_fields( 'my-external-plugin-settings-group' ); ?>
    <?php do_settings_sections( 'my-external-plugin-settings-group' ); ?>
    <table class="form-table">
	<?php   
	$external_add = get_option( 'external_add' );
	$new_tab = get_option( 'new_tab' );
	?>	
	<tr valign="top">
        <th scope="row">Apply attribute to content link:</th>
        <td><input type='checkbox' id='external_add' name='external_add' value='1' <?php echo checked( $external_add, 1, false );?> /></td>
        </tr>
			
    </table>
    
    <?php submit_button(); ?>

</form>
</div>
<?php }
$external_add = get_option('external_add');

if(checked( $external_add, 1, false )){
/**
* add external to links
*/
	function add_external_link($content) {
		$content = preg_replace_callback(
		'/<a[^>]*href=["|\']([^"|\']*)["|\'][^>]*>([^<]*)<\/a>/i',
		function($m) {
		if (strpos($m[1], $_SERVER['SERVER_NAME']) === false)
		return '<a id="ext-link" href="'.$m[1].'" rel="external" target="_blank">'.$m[2].'</a>';
		else
		return '<a  href="'.$m[1].'" >'.$m[2].'</a>';
		},
		$content);
		return $content;
	}
add_filter('the_content', 'add_external_link');
}
 ?>