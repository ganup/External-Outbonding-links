<?php
/*
Plugin Name: External outbonding links
Plugin URI: 
Version: 1.0
Author: Ganesh Paygude
Description: Add attribute for external links.
*/

/* Setup the plugin. */
add_action( 'plugins_loaded', 'eol_plugin_setup' );

/* Register plugin activation hook. */
register_activation_hook( __FILE__, 'eol_plugin_activation' );

/* Register plugin activation hook. */
register_deactivation_hook( __FILE__, 'eol_plugin_deactivation' );
/**
 * Do things on plugin activation.
 *
 */
function eol_plugin_activation() {
	/* Flush permalinks. */
    flush_rewrite_rules();
}
/**
 * Flush permalinks on plugin deactivation.
 */
function eol_plugin_deactivation() {
    flush_rewrite_rules();
}
function eol_plugin_setup() {
// create custom plugin settings menu
/* Get the plugin directory URI. */
	define( 'EXTERNAL_OUTBONDING_LINK_PLUGIN_URI', trailingslashit( plugin_dir_url( __FILE__ ) ) );
	add_action('admin_menu', 'eol_plugin_create_menu');

}

function eol_plugin_create_menu() {

	//create new top-level menu
	add_menu_page('External outbonding links', 'External outbonding links Settings', 'administrator', __FILE__, 'eol_plugin_settings_page' , plugins_url('/images/link.png', __FILE__) );

	//call register settings function
	add_action( 'admin_init', 'eol_register_plugin_settings' );
}
function eol_wp_enqueue_color_picker() {    
	
	wp_enqueue_script( 'my-script-handle', EXTERNAL_OUTBONDING_LINK_PLUGIN_URI . '/js/my-script.js', array( 'jquery' ), 0.1, true );
	
}
add_action( 'admin_enqueue_scripts', 'eol_wp_enqueue_color_picker' );

function eol_register_plugin_settings() {
	//register our settings	
	register_setting( 'eol-plugin-settings-group', 'external_add' );
}

function eol_plugin_settings_page() {
?>
<div class="wrap">
<h2>External outbonding links</h2>

<form method="post" action="options.php">
    <?php settings_fields( 'eol-plugin-settings-group' ); ?>
    <?php do_settings_sections( 'eol-plugin-settings-group' ); ?>
    <table class="form-table">
	<?php 	$eol_external_attribute_add = get_option( 'external_add' );	?>	
	
	<tr valign="top">
        <th scope="row">Apply attribute to content link:</th>
        <td><input type='checkbox' id='external_add' name='external_add' value='1' <?php echo checked( $eol_external_attribute_add, 1, false );?> /></td>
        </tr>
			
    </table>
    
    <?php submit_button(); ?>

</form>
</div>
<?php }
$eol_external_attribute_add = get_option('external_add');

if(checked( $eol_external_attribute_add, 1, false )){
/**
* add external to links
*/
	function eol_add_external_link($content) {
		$content = preg_replace_callback(
		'/<a[^>]*href=["|\']([^"|\']*)["|\'][^>]*>([^<]*)<\/a>/i',
		function($m) {
		if (strpos($m[1], $_SERVER['SERVER_NAME']) === false)
		return '<a id="ext-link" href="'.$m[1].'" rel="external" target="_blank">'.$m[2].'</a>';
		else
		return '<a  href="'.$m[1].'" >'.$m[2].'</a>';
		},
		$content);
		return $content;
	}
add_filter('the_content', 'eol_add_external_link');
}
 ?>